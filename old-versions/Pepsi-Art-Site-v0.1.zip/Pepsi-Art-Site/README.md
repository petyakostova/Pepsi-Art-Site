# Pepsi Art Site

###### Final Project in HTML & CSS Course

**Pepsi Art Site** is a site for my [Facebook page Pepsi Art (my artworks)](https://www.facebook.com/PepsiArtBG/ "Facebook page Pepsi Art (my artworks)") using HTML and CSS.

**Originally developed by:**
* Petya Kostova => [petyakostova](https://github.com/petyakostova)

**The Site is licensed under the GNU General Public License v3.0**

## Copyright Notice

**All artworks in this website are copyrighted and owned by the artist Petya Kostova. Any reproduction, modification, publication, transmission, transfer, or exploitation of any of the content, for personal or commercial use, whether in whole or in part, without written permission is copyright infringement and prohibited.**

### All Rights Reserved © Petya Kostova 2018

If you want to license any of my artworks for ads, merchandise, packaging, promotions or publishing, please contact me via email (pepsiart@abv.bg).
